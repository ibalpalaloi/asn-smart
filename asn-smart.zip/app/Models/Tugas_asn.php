<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Tugas_asn extends Model
{
    use HasFactory;
    protected $table = "tugas_asn";

}
